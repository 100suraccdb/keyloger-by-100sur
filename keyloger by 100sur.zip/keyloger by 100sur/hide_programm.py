'''FICHIER DE MAXIM, CACHER LE PROGRAMME'''

import win32gui
import win32con

def cacher_prog():
    # obtention du descripteur de la fenêtre actuelle
    hwnd = win32gui.GetForegroundWindow()

    # masquage de la fenêtre de la liste des tâches actives
    win32gui.ShowWindow(hwnd, win32con.SW_HIDE)