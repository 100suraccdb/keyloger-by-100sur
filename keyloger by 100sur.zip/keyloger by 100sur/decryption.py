import pyAesCrypt
import os


# fonction de déchiffrement de fichier
def dechiffrement(fichier, mot_de_passe):

    taille_tampon = 512 * 1024   # taille du tampon

    # appel de la méthode de déchiffrement
    pyAesCrypt.decryptFile(
        str(fichier),
        str(str(os.path.splitext(fichier)[0])),
        mot_de_passe,
        taille_tampon
    )

    print(f"Fichier {fichier} décodé")

    # suppression de la version non chiffrée du fichier
    os.remove(fichier)


def main_dechiffrement():

    # chemin absolu du fichier
    nom_fichier = 'system_monitoring.txt.crp'
    repertoire_courant = os.path.dirname(os.path.abspath(__file__))
    chemin_fichier = os.path.join(repertoire_courant, nom_fichier)

    mot_de_passe = 'qwerty'

    # vérification de l'existence du fichier
    if os.path.exists(chemin_fichier):
        dechiffrement(chemin_fichier, mot_de_passe)
    else:
        print(f'Fichier {chemin_fichier} non trouvé.')