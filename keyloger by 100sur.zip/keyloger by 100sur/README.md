# Enregistreur de frappes
Enregistreur de frappes
Avec les fonctionnalités :

1. Scanne tout le clavier et enregistre tous les journaux dans un fichier.txt
2. Envoie automatiquement les journaux à votre adresse e-mail toutes les 30 minutes
3. Affiche l'heure de réception des journaux
4. Se cache du système
5. Chiffre le fichier des journaux
6. Démarrage automatique (se lance au démarrage du système)
7. Crée par 100sur discord -> .accdb