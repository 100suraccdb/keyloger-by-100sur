import pyAesCrypt
import os


# fonction de chiffrement de fichier
def chiffrement_fichier(fichier, mot_de_passe):

    taille_tampon = 512 * 1024   # taille du tampon

    # appel de la méthode de chiffrement
    pyAesCrypt.encryptFile(
        str(fichier),
        str(fichier) + '.crp',
        mot_de_passe,
        taille_tampon
    )

    print(f'Le fichier {fichier} a été chiffré')

    # suppression de la version non chiffrée du fichier
    # os.remove(fichier)


def main_chiffrement():
    # chemin absolu du fichier
    nom_fichier = 'surveillance_systeme.txt'
    repertoire_courant = os.path.dirname(os.path.abspath(__file__))
    chemin_fichier = os.path.join(repertoire_courant, nom_fichier)

    mot_de_passe = 'qwerty'

    # vérification de l'existence du fichier
    if os.path.exists(chemin_fichier):
        chiffrement_fichier(chemin_fichier, mot_de_passe)
    else:
        print(f'Le fichier {chemin_fichier} n\'a pas été trouvé')